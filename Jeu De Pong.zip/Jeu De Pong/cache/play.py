import os
os.system("python game.py")