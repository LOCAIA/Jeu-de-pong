from tkinter import *

def pression(evt):
    print("Appui sur", evt.keysym)

def relachement(evt):
    print("Fin de l'appui sur", evt.keysym)

f = Tk()
f.bind('<KeyPress>', pression)
f.bind('<KeyRelease>', relachement)
f.mainloop()