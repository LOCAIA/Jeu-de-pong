import subprocess
import time

class KBOARD:
    def __init__(self):
        self.capteur = ""
        self.process = None

    def start_capture(self):
        self.process = subprocess.Popen(["cscript", "//NoLogo", "KBOARD.vbs"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        self._read_output()

    def _read_output(self):
        while True:
            line = self.process.stdout.readline().strip()
            if line:
                self.capteur += line

    def stop_capture(self):
        if self.process:
            self.process.terminate()

    def get_keys(self):
        keys = self.capteur
        self.capteur = ""
        return keys

# Exemple d'utilisation
if __name__ == "__main__":
    kb = KBOARD()
    kb.start_capture()
    time.sleep(5)  # Capture pendant 5 secondes
    kb.stop_capture()
    print("Touches capturées:", kb.get_keys())
