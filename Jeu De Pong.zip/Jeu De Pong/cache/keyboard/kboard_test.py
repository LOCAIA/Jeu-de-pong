from KBOARD import KBOARD

def main():
    kb = KBOARD()
    kb.start_capture()
    
    try:
        while True:
            keys = kb.get_keys()
            input("")
            if 'a' in keys.lower():
                print("Tu as appuyé sur 'A'")
    except KeyboardInterrupt:
        print("\nArrêt du programme.")
    finally:
        kb.stop_capture()

if __name__ == "__main__":
    main()
